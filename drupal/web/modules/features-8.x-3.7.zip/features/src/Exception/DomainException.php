<?php

namespace Drupal\features\Exception;

class DomainException extends \DomainException {

}
